package com.example.kadai_002;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kadai002ApplicationTests {

	@Test
	void contextLoads() {
	}

}
